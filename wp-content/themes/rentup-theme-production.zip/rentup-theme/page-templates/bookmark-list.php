<?php
/**
 * Template Name: Bookmark List
 *
 * Auto-converted from bookmark-list.html
 * Preserves exact original HTML markup, classes, and structure.
 *
 * @package Murailles Immobilier
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

get_header();
?>

<!-- ============================ Page Title Start================================== -->
			<div class="page-title" style="background:#f4f4f4 url(<?php echo esc_url( murailles_img( 'banner-home.jpg' ) ); ?>);" data-overlay="5">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							
							<div class="breadcrumbs-wrap position-relative z-1">
								<ol class="breadcrumb">
									<li class="breadcrumb-item active" aria-current="page">Saved Properties</li>
								</ol>
								<h2 class="breadcrumb-title">Your All Saved Properties</h2>
							</div>
							
						</div>
					</div>
				</div>
			</div>
			<!-- ============================ Page Title End ================================== -->
			
			<!-- ============================ User Dashboard ================================== -->
			<section class="gray pt-5 pb-5">
				<div class="container-fluid">
								
					<div class="row">
						
						<div class="col-lg-3 col-md-4">
							<div class="property_dashboard_navbar">
								
								<div class="dash_user_avater">
									<img src="<?php echo esc_url( murailles_img( 'user-3.jpg' ) ); ?>" class="img-fluid avater" alt="">
									<h4>Adam Harshvardhan</h4>
									<span>Canada USA</span>
								</div>
								
								<div class="dash_user_menues">
									<ul>
										<li><a href="<?php echo esc_url( home_url( '/dashboard/' ) ); ?>"><i class="fa fa-tachometer-alt"></i>Dashboard<span class="notti_coun style-1">4</span></a></li>
										<li><a href="<?php echo esc_url( home_url( '/my-profile/' ) ); ?>"><i class="fa fa-user-tie"></i>My Profile</a></li>
										<li class="active"><a href="<?php echo esc_url( home_url( '/bookmark-list/' ) ); ?>"><i class="fa fa-bookmark"></i>Saved Property<span class="notti_coun style-2">7</span></a></li>
										<li><a href="<?php echo esc_url( home_url( '/my-property/' ) ); ?>"><i class="fa fa-tasks"></i>My Properties</a></li>
										<li><a href="<?php echo esc_url( home_url( '/messages/' ) ); ?>"><i class="fa fa-envelope"></i>Messages<span class="notti_coun style-3">3</span></a></li>
										<li><a href="<?php echo esc_url( home_url( '/pricing/' ) ); ?>"><i class="fa fa-gift"></i>Choose Package<span class="expiration">10 days left</span></a></li>
										<li><a href="<?php echo esc_url( home_url( '/dashboard/' ) ); ?>"><i class="fa fa-pen-nib"></i>Submit New Property</a></li>
										<li><a href="<?php echo esc_url( home_url( '/my-profile/' ) ); ?>"><i class="fa fa-unlock-alt"></i>Change Password</a></li>
									</ul>
								</div>
								
								<div class="dash_user_footer">
									<ul>
										<li><a href="#"><i class="fa fa-power-off"></i></a></li>
										<li><a href="#"><i class="fa fa-comment"></i></a></li>
										<li><a href="#"><i class="fa fa-cog"></i></a></li>
									</ul>
								</div>
								
							</div>
						</div>
						
						<div class="col-lg-9 col-md-8 col-sm-12">
							<div class="dashboard-body">
							
								<div class="dashboard-wraper">
								
									<!-- Bookmark Property -->
									<div class="frm_submit_block">	
										<h4>Bookmark Property</h4>
									</div>
									
									<table class="property-table-wrap responsive-table bkmark">

										<tbody>
											<tr>
												<th><i class="fa fa-file-text"></i> Property</th>
												<th></th>
											</tr>

											<!-- Item #1 -->
											<tr>
												<td class="dashboard_propert_wrapper">
													<img src="<?php echo esc_url( murailles_img( 'p-2.png' ) ); ?>" alt="">
													<div class="title">
														<h4><a href="#">Serene Uptown</a></h4>
														<span>6 Bishop Ave. Perkasie, PA </span>
														<span class="table-property-price">$900 / monthly</span>
													</div>
												</td>
												<td class="action">
													<a href="#" class="delete"><i class="ti-close"></i> Delete</a>
												</td>
											</tr>

											<!-- Item #2 -->
											<tr>
												<td class="dashboard_propert_wrapper">
													<img src="<?php echo esc_url( murailles_img( 'p-3.png' ) ); ?>" alt="">
													<div class="title">
														<h4><a href="#">Oak Tree Villas</a></h4>
														<span>71 Lower River Dr. Bronx, NY</span>
														<span class="table-property-price">$535,000</span>
													</div>
												</td>
												<td class="action">
													<a href="#" class="delete"><i class="ti-close"></i> Delete</a>
												</td>
											</tr>

											<!-- Item #3 -->
											<tr>
												<td class="dashboard_propert_wrapper">
													<img src="<?php echo esc_url( murailles_img( 'p-4.png' ) ); ?>" alt="">
													<div class="title">
														<h4><a href="#">Selway Villas</a></h4>
														<span>33 William St. Northbrook, IL </span>
														<span class="table-property-price">$420,000</span>
													</div>
												</td>
												<td class="action">
													<a href="#" class="delete"><i class="ti-close"></i> Delete</a>
												</td>
											</tr>

											<!-- Item #4 -->
											<tr>
												<td class="dashboard_propert_wrapper">
													<img src="<?php echo esc_url( murailles_img( 'p-5.png' ) ); ?>" alt="">
													<div class="title">
														<h4><a href="#">Town Manchester</a></h4>
														<span> 7843 Durham Avenue, MD  </span>
														<span class="table-property-price">$420,000</span>
													</div>
												</td>
												<td class="action">
													<a href="#" class="delete"><i class="ti-close"></i> Delete</a>
												</td>
											</tr>

										</tbody>
									</table>
									
								</div>
							
							</div>
						</div>
						
					</div>
				</div>
			</section>
			<!-- ============================ User Dashboard End ================================== -->

<?php murailles_render_page_builder_content(); ?>

<?php get_template_part( 'template-parts/call-to-action' ); ?>

<?php get_footer(); ?>
